﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Course choice;

        // Global variables to track state across button clicks
        private int totalCredits = 0;
        private const int MAX_CREDITS = 9;
        private const int COURSE_CREDITS = 3;

        public MainWindow()
        {
            InitializeComponent();

            // Sets your last name as the first printed text in the window title bar
            this.Title = "Bailey - WPF Register Student";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");

            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);

            // Start the textbox off displaying 0 total credit hours
            this.textBox.Text = totalCredits.ToString();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // Reset message styles at the start of each click
            label3.Content = "";
            label3.Foreground = Brushes.Red;

            // 1. Map User Input & Validate Selection
            if (this.comboBox.SelectedItem == null)
            {
                label3.Content = "Error: Please select a course from the drop-down menu.";
                return;
            }

            choice = (Course)(this.comboBox.SelectedItem);

            // 2. Boolean Logic: Check for Duplicate Registration Business Rule
            foreach (Course registeredCourse in this.listBox.Items)
            {
                if (registeredCourse.ToString() == choice.ToString())
                {
                    label3.Content = $"Error: You are already registered for {choice.ToString()}.";
                    return;
                }
            }

            // 3. Boolean Logic: Check Credit Limit Business Rule (Max 9 Credits)
            if (totalCredits + COURSE_CREDITS > MAX_CREDITS)
            {
                label3.Content = "Error: Cannot exceed a maximum of 9 credit hours (3 courses).";
                return;
            }

            // 4. Program Math Operations & UI Code Updates (If checks pass)
            totalCredits += COURSE_CREDITS;
            this.textBox.Text = totalCredits.ToString();

            // Add the confirmed course object to the registration list box
            this.listBox.Items.Add(choice);

            // Output confirmation message in Green
            label3.Foreground = Brushes.Green;
            label3.Content = $"Success: Successfully registered for {choice.ToString()}!";
        }
    }
}